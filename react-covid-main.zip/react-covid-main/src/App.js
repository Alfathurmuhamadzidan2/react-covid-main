import Home from "./pages/Home";

function App() {
  return (
    <div>
      {/*
       * Render Halaman Home
       * Jika ingin diubah, maka ubah di Halaman Home.
       */}
      <Home />
    </div>
  );
}

export default App;
