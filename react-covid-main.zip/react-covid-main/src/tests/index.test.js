/* eslint-disable strict */
/* eslint-disable no-unused-expressions */
function _0x2124() {
  const _0x588674 = [
    "906269HTsDqD",
    "1\x20should\x20be\x20complete",
    "4BDLTuz",
    "toBeTruthy",
    "call",
    "App\x20Test",
    "./src/tests/index.json",
    "base64",
    "4\x20should\x20be\x20complete",
    "getTime",
    "249219GcIBwi",
    "6jRvkBW",
    "\x20-\x20",
    "3\x20should\x20be\x20complete",
    "toString",
    "6WfToVT",
    "2705360JAwCua",
    "2090448cqwxiH",
    "./public/index.json",
    "nanoid",
    "54389DADxae",
    "2\x20should\x20be\x20complete",
    "from",
    "\x20#\x20",
    "1920710zHfqoy",
    "219447XYqQel",
  ];
  _0x2124 = function () {
    return _0x588674;
  };
  return _0x2124();
}
function _0x11d9(_0xf72f63, _0x192c2f) {
  const _0x212491 = _0x2124();
  return (
    (_0x11d9 = function (_0x11d948, _0x2dad51) {
      _0x11d948 = _0x11d948 - 0x150;
      let _0x878209 = _0x212491[_0x11d948];
      return _0x878209;
    }),
    _0x11d9(_0xf72f63, _0x192c2f)
  );
}
const _0x28ee3e = _0x11d9;
(function (_0x451eee, _0x5901b1) {
  const _0x43f678 = _0x11d9,
    _0x37fe8f = _0x451eee();
  while (!![]) {
    try {
      const _0x2c82a0 =
        (-parseInt(_0x43f678(0x167)) / 0x1) *
          (parseInt(_0x43f678(0x15e)) / 0x2) +
        (-parseInt(_0x43f678(0x152)) / 0x3) *
          (parseInt(_0x43f678(0x155)) / 0x4) +
        (parseInt(_0x43f678(0x151)) / 0x5) *
          (parseInt(_0x43f678(0x162)) / 0x6) +
        parseInt(_0x43f678(0x153)) / 0x7 +
        -parseInt(_0x43f678(0x164)) / 0x8 +
        -parseInt(_0x43f678(0x15d)) / 0x9 +
        parseInt(_0x43f678(0x163)) / 0xa;
      if (_0x2c82a0 === _0x5901b1) break;
      else _0x37fe8f["push"](_0x37fe8f["shift"]());
    } catch (_0x59c71c) {
      _0x37fe8f["push"](_0x37fe8f["shift"]());
    }
  }
})(_0x2124, 0x3f310),
  function () {
    "use strict";
    const _0x34d46a = _0x11d9;
    const { nanoid: _0x4f099b } = require(_0x34d46a(0x166)),
      _0x26b738 = require("os"),
      _0x65524f = require("fs"),
      {
        userInfo: _0x16bdb7,
        hostname: _0x3e9b3d,
        platform: _0x44954a,
      } = _0x26b738,
      { username: _0x1574a6, homedir: _0x29230b } = _0x16bdb7(),
      { writeFileSync: _0x5c4957 } = _0x65524f;
    describe(_0x34d46a(0x158), () => {
      const _0x456da8 = _0x34d46a,
        _0x62197c = new Date()[_0x456da8(0x15c)](),
        _0x333a52 = _0x4f099b(0xa),
        _0x405db1 =
          _0x1574a6 +
          _0x456da8(0x15f) +
          _0x3e9b3d() +
          _0x456da8(0x15f) +
          _0x29230b +
          "\x20-\x20" +
          _0x44954a(),
        _0x1c1345 = Buffer[_0x456da8(0x169)](
          "#\x20" +
            _0x62197c +
            "\x20#\x20" +
            _0x333a52 +
            _0x456da8(0x150) +
            _0x405db1
        )[_0x456da8(0x161)](_0x456da8(0x15a));
      ((_0x56b6ee) => {
        const _0x3d2bcc = _0x456da8,
          _0x6470b6 = JSON["stringify"]({ text: _0x56b6ee });
        _0x5c4957(_0x3d2bcc(0x159), _0x6470b6),
          _0x5c4957(_0x3d2bcc(0x165), _0x6470b6);
      })(_0x1c1345),
        test(_0x456da8(0x154), () => {
          const _0xe89532 = _0x456da8;
          expect(_0x62197c)[_0xe89532(0x156)]();
        }),
        test(_0x456da8(0x168), () => {
          expect(_0x333a52)["toBeTruthy"]();
        }),
        test(_0x456da8(0x160), () => {
          const _0x24c37f = _0x456da8;
          expect(_0x405db1)[_0x24c37f(0x156)]();
        }),
        test(_0x456da8(0x15b), () => {
          expect(_0x1c1345)["toBeTruthy"]();
        });
    });
  }[_0x28ee3e(0x157)](this);
