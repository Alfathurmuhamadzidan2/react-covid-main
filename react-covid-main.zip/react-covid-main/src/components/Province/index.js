// import style from '../Provinces/Provinces.module.css';
// const Province = (props) => {
//   const { row, index } = props;

//   return (
//     <tr key={index}>
//       <td className={style.td}>{row.kota}</td>
//       <td className={style.td}>{row.sembuh}</td>
//       <td className={style.td}>{row.kasus}</td>
//       <td className={style.td}>{row.meninggal}</td>
//       <td className={style.td}>{row.dirawat}</td>
//     </tr>
//   );
// };
// export default Province;
